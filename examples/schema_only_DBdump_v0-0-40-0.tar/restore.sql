--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "FA_study";
--
-- Name: FA_study; Type: DATABASE; Schema: -; Owner: sp1022
--

CREATE DATABASE "FA_study" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE "FA_study" OWNER TO sp1022;

\connect "FA_study"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _human_obs_log; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public._human_obs_log (
    subject_id character varying(255) NOT NULL,
    study_id character varying(255) NOT NULL,
    observer_id character varying(255) NOT NULL,
    human_obs_id character varying(255) NOT NULL,
    application_id character varying(255) NOT NULL,
    response_array character varying(255) NOT NULL,
    site_id character varying(255),
    date_time date
);


ALTER TABLE public._human_obs_log OWNER TO neuroboother;

--
-- Name: _observer; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public._observer (
    observer_id character varying(255) NOT NULL,
    subject_id character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    age integer NOT NULL,
    sex character varying(255) NOT NULL,
    race character varying(255) NOT NULL,
    ethnicity character varying(255) NOT NULL,
    relationship character varying(255) NOT NULL
);


ALTER TABLE public._observer OWNER TO neuroboother;

--
-- Name: log_application_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_application_id_seq OWNER TO neuroboother;

--
-- Name: log_application; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_application (
    id integer DEFAULT nextval('public.log_application_id_seq'::regclass) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_id character varying(255),
    subject_id character varying(255),
    server_type character varying(255),
    server_id character varying(255),
    server_time timestamp with time zone NOT NULL,
    log_level character varying(255),
    filename character varying(255),
    function character varying(255),
    line_no integer,
    device character varying(255),
    message text,
    traceback text
);


ALTER TABLE public.log_application OWNER TO neuroboother;

--
-- Name: log_device_param; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_device_param (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    device_id character varying(255) NOT NULL,
    device_name character varying(255) NOT NULL,
    device_sn character varying(255),
    wearable_bool boolean NOT NULL,
    arg_parser character varying(510) NOT NULL,
    additional_data jsonb,
    sensor_array jsonb
);


ALTER TABLE public.log_device_param OWNER TO neuroboother;

--
-- Name: log_device_param_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_device_param_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_device_param_id_seq OWNER TO neuroboother;

--
-- Name: log_device_param_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neuroboother
--

ALTER SEQUENCE public.log_device_param_id_seq OWNED BY public.log_device_param.id;


--
-- Name: log_file; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_file (
    operation_id integer NOT NULL,
    log_sensor_file_id text,
    src_dirname text,
    dest_dirname text,
    fname text,
    time_verified timestamp without time zone,
    rsync_operation text,
    is_deleted boolean,
    is_finished boolean
);


ALTER TABLE public.log_file OWNER TO neuroboother;

--
-- Name: log_file_operation_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_file_operation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_file_operation_id_seq OWNER TO neuroboother;

--
-- Name: log_file_operation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neuroboother
--

ALTER SEQUENCE public.log_file_operation_id_seq OWNED BY public.log_file.operation_id;


--
-- Name: sensor_file_log_sensor_file_id; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.sensor_file_log_sensor_file_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensor_file_log_sensor_file_id OWNER TO neuroboother;

--
-- Name: log_sensor_file; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_sensor_file (
    log_sensor_file_id character varying(255) DEFAULT ('sens_log_'::text || nextval('public.sensor_file_log_sensor_file_id'::regclass)) NOT NULL,
    log_task_id character varying(255) NOT NULL,
    true_temporal_resolution double precision,
    true_spatial_resolution double precision,
    file_start_time timestamp without time zone NOT NULL,
    file_end_time timestamp without time zone NOT NULL,
    device_id character varying(255) NOT NULL,
    sensor_id character varying(255) NOT NULL,
    sensor_file_path text[],
    log_session_id integer,
    CONSTRAINT sensor_file_log_sensor_file_id_chk CHECK (((log_sensor_file_id)::text ~ '^sens_log_[0-9]+$'::text))
);


ALTER TABLE public.log_sensor_file OWNER TO neuroboother;

--
-- Name: log_session; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_session (
    log_session_id integer NOT NULL,
    subject_id character varying(255),
    date date,
    study_id text,
    visit_id text,
    collection_id text,
    staff_id text,
    application_id text
);


ALTER TABLE public.log_session OWNER TO neuroboother;

--
-- Name: log_session_log_session_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_session_log_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_session_log_session_id_seq OWNER TO neuroboother;

--
-- Name: log_session_log_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neuroboother
--

ALTER SEQUENCE public.log_session_log_session_id_seq OWNED BY public.log_session.log_session_id;


--
-- Name: log_split; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_split (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    subject_id character varying(255) NOT NULL,
    date date NOT NULL,
    task_id character varying(255) NOT NULL,
    device_id character varying(255) NOT NULL,
    sensor_id character varying(255) NOT NULL,
    hdf5_file_path text NOT NULL,
    xdf_path text,
    log_sensor_file_id character varying(255),
    true_temporal_resolution double precision,
    true_spatial_resolution double precision,
    file_start_time timestamp without time zone,
    file_end_time timestamp without time zone,
    sensor_file_path character varying[],
    log_session_id integer
);


ALTER TABLE public.log_split OWNER TO neuroboother;

--
-- Name: log_split_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

ALTER TABLE public.log_split ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.log_split_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: log_system_resource; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_system_resource (
    machine_name character varying(31) NOT NULL,
    session_start timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    ram_used bigint NOT NULL,
    ram_total bigint NOT NULL,
    swap_used bigint NOT NULL,
    swap_total bigint NOT NULL,
    net_recd bigint NOT NULL,
    net_sent bigint NOT NULL,
    disk_usage jsonb NOT NULL,
    cpu_usage jsonb NOT NULL
);


ALTER TABLE public.log_system_resource OWNER TO neuroboother;

--
-- Name: tech_obs_log_tech_obs_log_id; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.tech_obs_log_tech_obs_log_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tech_obs_log_tech_obs_log_id OWNER TO neuroboother;

--
-- Name: log_task; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_task (
    log_task_id character varying(255) DEFAULT ('tech_log_'::text || nextval('public.tech_obs_log_tech_obs_log_id'::regclass)) NOT NULL,
    task_id character varying(255),
    event_array text,
    date_times timestamp without time zone[],
    subject_id character varying(255),
    log_session_id integer,
    task_notes_file text,
    task_output_files text[]
);


ALTER TABLE public.log_task OWNER TO neuroboother;

--
-- Name: log_task_param; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.log_task_param (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    log_task_id character varying NOT NULL,
    task_id character varying NOT NULL,
    instr_args jsonb,
    stim_args jsonb NOT NULL,
    task_constructor_callable character varying NOT NULL,
    arg_parser character varying,
    additional_data jsonb,
    log_device_ids integer[]
);


ALTER TABLE public.log_task_param OWNER TO neuroboother;

--
-- Name: log_task_param_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_task_param_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_task_param_id_seq OWNER TO neuroboother;

--
-- Name: log_task_params_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.log_task_params_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_task_params_id_seq OWNER TO neuroboother;

--
-- Name: log_task_params_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neuroboother
--

ALTER SEQUENCE public.log_task_params_id_seq OWNED BY public.log_task_param.id;


--
-- Name: message_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.message_queue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_queue_id_seq OWNER TO neuroboother;

--
-- Name: message_queue; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.message_queue (
    id bigint DEFAULT nextval('public.message_queue_id_seq'::regclass) NOT NULL,
    msg_type character varying(24) NOT NULL,
    source character varying(24) NOT NULL,
    destination character varying(24) NOT NULL,
    priority smallint NOT NULL,
    body jsonb NOT NULL,
    time_created timestamp with time zone DEFAULT now() NOT NULL,
    time_read timestamp with time zone,
    full_msg_type character varying NOT NULL,
    uuid character varying NOT NULL
);


ALTER TABLE public.message_queue OWNER TO neuroboother;

--
-- Name: nex_annotations; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.nex_annotations (
    annotation_id integer NOT NULL,
    subject_id character varying(255) NOT NULL,
    session_datetime timestamp without time zone NOT NULL,
    gender character varying(1),
    age integer,
    primary_diagnosis character varying[],
    task_id character varying(255) NOT NULL,
    annotation text NOT NULL,
    annotator_name character varying(255) NOT NULL,
    annotation_source character varying(255),
    source_user_id character varying(255),
    annotation_submit_time timestamp without time zone
);


ALTER TABLE public.nex_annotations OWNER TO neuroboother;

--
-- Name: nex_annotations_annotation_id_seq; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.nex_annotations_annotation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nex_annotations_annotation_id_seq OWNER TO neuroboother;

--
-- Name: nex_annotations_annotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neuroboother
--

ALTER SEQUENCE public.nex_annotations_annotation_id_seq OWNED BY public.nex_annotations.annotation_id;


--
-- Name: sensor_file_log_sensor_file_log; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.sensor_file_log_sensor_file_log
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensor_file_log_sensor_file_log OWNER TO neuroboother;

--
-- Name: sensor_file_log_sensor_file_log_id; Type: SEQUENCE; Schema: public; Owner: neuroboother
--

CREATE SEQUENCE public.sensor_file_log_sensor_file_log_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensor_file_log_sensor_file_log_id OWNER TO neuroboother;

--
-- Name: subject; Type: TABLE; Schema: public; Owner: neuroboother
--

CREATE TABLE public.subject (
    subject_id character varying(255) NOT NULL,
    first_name_birth character varying(255) NOT NULL,
    middle_name_birth character varying(255),
    last_name_birth character varying(255) NOT NULL,
    date_of_birth_subject date NOT NULL,
    country_of_birth character varying(255),
    gender_at_birth character varying(255),
    birthplace text,
    guid character varying(255),
    old_subject_id character varying(255),
    redcap_event_name character varying(255) NOT NULL
);


ALTER TABLE public.subject OWNER TO neuroboother;

--
-- Name: log_device_param id; Type: DEFAULT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_device_param ALTER COLUMN id SET DEFAULT nextval('public.log_device_param_id_seq'::regclass);


--
-- Name: log_file operation_id; Type: DEFAULT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_file ALTER COLUMN operation_id SET DEFAULT nextval('public.log_file_operation_id_seq'::regclass);


--
-- Name: log_session log_session_id; Type: DEFAULT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_session ALTER COLUMN log_session_id SET DEFAULT nextval('public.log_session_log_session_id_seq'::regclass);


--
-- Name: log_task_param id; Type: DEFAULT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_task_param ALTER COLUMN id SET DEFAULT nextval('public.log_task_params_id_seq'::regclass);


--
-- Name: nex_annotations annotation_id; Type: DEFAULT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.nex_annotations ALTER COLUMN annotation_id SET DEFAULT nextval('public.nex_annotations_annotation_id_seq'::regclass);


--
-- Name: _human_obs_log human_obs_log_pk; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public._human_obs_log
    ADD CONSTRAINT human_obs_log_pk PRIMARY KEY (subject_id, study_id);


--
-- Name: log_application log_application_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_application
    ADD CONSTRAINT log_application_pkey PRIMARY KEY (id);


--
-- Name: log_device_param log_device_param_pk; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_device_param
    ADD CONSTRAINT log_device_param_pk PRIMARY KEY (id);


--
-- Name: log_file log_file_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_file
    ADD CONSTRAINT log_file_pkey PRIMARY KEY (operation_id);


--
-- Name: log_session log_session_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_session
    ADD CONSTRAINT log_session_pkey PRIMARY KEY (log_session_id);


--
-- Name: log_split log_split_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_split
    ADD CONSTRAINT log_split_pkey PRIMARY KEY (id);


--
-- Name: log_system_resource log_system_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_system_resource
    ADD CONSTRAINT log_system_resource_pkey PRIMARY KEY (machine_name, session_start, created_at);


--
-- Name: log_task_param log_task_params_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_task_param
    ADD CONSTRAINT log_task_params_pkey PRIMARY KEY (id);


--
-- Name: message_queue message_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.message_queue
    ADD CONSTRAINT message_queue_pkey PRIMARY KEY (id);


--
-- Name: nex_annotations nex_annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.nex_annotations
    ADD CONSTRAINT nex_annotations_pkey PRIMARY KEY (annotation_id);


--
-- Name: _observer observer_pk; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public._observer
    ADD CONSTRAINT observer_pk PRIMARY KEY (observer_id);


--
-- Name: log_sensor_file sensor_file_log_pk; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_sensor_file
    ADD CONSTRAINT sensor_file_log_pk PRIMARY KEY (log_sensor_file_id);


--
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (subject_id);


--
-- Name: log_task tech_obs_log_pk; Type: CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_task
    ADD CONSTRAINT tech_obs_log_pk PRIMARY KEY (log_task_id);


--
-- Name: subject_identifier; Type: INDEX; Schema: public; Owner: neuroboother
--

CREATE UNIQUE INDEX subject_identifier ON public.subject USING btree (first_name_birth, last_name_birth, date_of_birth_subject);


--
-- Name: _human_obs_log human_obs_log_fk0; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public._human_obs_log
    ADD CONSTRAINT human_obs_log_fk0 FOREIGN KEY (subject_id) REFERENCES public.subject(subject_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _human_obs_log human_obs_log_fk2; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public._human_obs_log
    ADD CONSTRAINT human_obs_log_fk2 FOREIGN KEY (observer_id) REFERENCES public._observer(observer_id);


--
-- Name: log_file log_file_log_sensor_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_file
    ADD CONSTRAINT log_file_log_sensor_file_id_fkey FOREIGN KEY (log_sensor_file_id) REFERENCES public.log_sensor_file(log_sensor_file_id);


--
-- Name: log_task log_session_id_fk3; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_task
    ADD CONSTRAINT log_session_id_fk3 FOREIGN KEY (log_session_id) REFERENCES public.log_session(log_session_id) NOT VALID;


--
-- Name: log_sensor_file sensor_file_log_fk2; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_sensor_file
    ADD CONSTRAINT sensor_file_log_fk2 FOREIGN KEY (log_task_id) REFERENCES public.log_task(log_task_id);


--
-- Name: log_sensor_file sensor_file_log_fk7; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_sensor_file
    ADD CONSTRAINT sensor_file_log_fk7 FOREIGN KEY (log_session_id) REFERENCES public.log_session(log_session_id) NOT VALID;


--
-- Name: log_task tech_obs_log_fk0; Type: FK CONSTRAINT; Schema: public; Owner: neuroboother
--

ALTER TABLE ONLY public.log_task
    ADD CONSTRAINT tech_obs_log_fk0 FOREIGN KEY (subject_id) REFERENCES public.subject(subject_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TABLE _human_obs_log; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public._human_obs_log TO neurovisualizer;


--
-- Name: TABLE _observer; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public._observer TO neurovisualizer;


--
-- Name: TABLE log_application; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_application TO PUBLIC;


--
-- Name: TABLE log_device_param; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_device_param TO PUBLIC;


--
-- Name: TABLE log_file; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_file TO PUBLIC;


--
-- Name: SEQUENCE sensor_file_log_sensor_file_id; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON SEQUENCE public.sensor_file_log_sensor_file_id TO neurovisualizer;


--
-- Name: TABLE log_sensor_file; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_sensor_file TO neurovisualizer;


--
-- Name: TABLE log_session; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_session TO PUBLIC;


--
-- Name: TABLE log_split; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_split TO PUBLIC;
GRANT SELECT ON TABLE public.log_split TO neurovisualizer;


--
-- Name: TABLE log_system_resource; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_system_resource TO PUBLIC;


--
-- Name: SEQUENCE tech_obs_log_tech_obs_log_id; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON SEQUENCE public.tech_obs_log_tech_obs_log_id TO neurovisualizer;


--
-- Name: TABLE log_task; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_task TO neurovisualizer;


--
-- Name: TABLE log_task_param; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.log_task_param TO PUBLIC;


--
-- Name: TABLE message_queue; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.message_queue TO PUBLIC;


--
-- Name: TABLE nex_annotations; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.nex_annotations TO PUBLIC;


--
-- Name: SEQUENCE sensor_file_log_sensor_file_log; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON SEQUENCE public.sensor_file_log_sensor_file_log TO neurovisualizer;


--
-- Name: SEQUENCE sensor_file_log_sensor_file_log_id; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON SEQUENCE public.sensor_file_log_sensor_file_log_id TO neurovisualizer;


--
-- Name: TABLE subject; Type: ACL; Schema: public; Owner: neuroboother
--

GRANT SELECT ON TABLE public.subject TO neurovisualizer;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: neuroboother
--

ALTER DEFAULT PRIVILEGES FOR ROLE neuroboother IN SCHEMA public REVOKE ALL ON TABLES  FROM neuroboother;
ALTER DEFAULT PRIVILEGES FOR ROLE neuroboother IN SCHEMA public GRANT SELECT ON TABLES  TO PUBLIC;


--
-- PostgreSQL database dump complete
--

